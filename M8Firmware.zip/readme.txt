-= Temporary Instructions for M8 Production and Beta unit owners =-

For Windows 7 Only - Download and install Teensyduino to install the USB driver needed for flashing M8 firmware:
https://www.pjrc.com/teensy/td_download.html

Windows (7/8/10) and MacOS:
Download & Install TyTools:
https://github.com/Koromix/tytools/releases

1. Unzip the Firmware. (Yay you did this!)
2. Plug in M8 via USB DO NOT USE A USB HUB IF IT CAN BE AVOIDED
3. Turn M8 on.
4. Close all other applications
5. Open "TyUpdater" - Note: "TyCommander" was also installed, don't use that.
6. Make sure "M8 [xxxxxxxx]" is selected in the dropdown if you have other Teensy devices plugged into your computer.
7. Click "Upload" select the .hex file from this zip file.