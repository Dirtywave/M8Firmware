-= Temporary Instructions for M8 Limited edition owners =-

For Windows 7 Only - Download and install Teensyduino to install the USB driver needed for flashing M8 firmware:
https://www.pjrc.com/teensy/td_download.html

Windows (7/8/10) and OSX:
Download & Install TyTools:
https://github.com/Koromix/tytools/releases

1. Unzip the Firmware. (Yay you did this!)
2. Plug in M8 via USB DO NOT USE A USB HUB IF IT CAN BE AVOIDED
3. Close all other applications
4. Open "TyUpdater" - Note: "TyCommander" was also installed, don't use that.
5. Make sure "M8 [xxxxxxxx]" is selected in the dropdown if you have other Teensy devices plugged into your computer.
6. Click "Upload" select the .hex file from this zip file.